COLUMNS = {
    "id": 0,
    "date": 1,
    "transaction": 2
}

FORMAT_DATE = "%m/%d"
FORMAT_MONTH = "%B"
USERNAME = "danycduran@gmail.com"
PASSWORD = "StoriStori"
PORT_EMAIL = 587
HOST_EMAIL = "smtp.gmail.com"
