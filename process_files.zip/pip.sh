#!/bin/sh

pip install -r ./src/requirements.txt -t ./src/